  <script>
        var nombreDiaSemanaLink = document.getElementById('nombreDiaSemanaLink');
        nombreDiaSemanaLink.addEventListener('click', function () {
            this.setAttribute('download', 'NombreDiaSemana.pas');
        });
    </script>